Personal Class Website
By Azmat Ishaq

This is a website made for class DART 349 at Concordia University.

Image sources:

Sports - Sports Clipart Transparent Background Emoji,Sport Emoji - free transparent emoji - emojipng.com
https://www.emojipng.com/preview/1677682

Free Guitar Clipart Transparent - Guitar Clipart Emoji,Guitar Emoji Png - free transparent emoji - emojipng.com
https://www.emojipng.com/preview/3861718

Gaming Emoji Png Picture - Gaming Controller Emoji Png,Game Controller Emoji - free transparent emoji - emojipng.com
https://www.emojipng.com/preview/354981

Stack Of Books Clipart - Transparent Background Books Clipart Emoji,Stack Of Books Emoji - free transparent emoji - emojipng.com
https://www.emojipng.com/preview/3882612

Image editing done with:

PixelMe : Convert your photo into pixelart.
https://pixel-me.tokyo/en/
