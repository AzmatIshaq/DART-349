# Final Project for DART-349

##Professor Santo Romano

Code sources:


Scroll to top:
https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_scroll_to_top


Background animation:
https://stackoverflow.com/questions/40269514/animate-a-div-background-image